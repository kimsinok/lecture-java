# boardapp
Spring과 MyBatis 연동
