package com.example.boardapp.util;

import lombok.Data;

@Data
public class Criteria {

    private final String keyfield;
    private final String keyword;

}
